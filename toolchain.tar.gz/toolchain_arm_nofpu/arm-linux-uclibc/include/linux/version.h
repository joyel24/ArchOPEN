#define UTS_RELEASE "2.4.21"
#define LINUX_VERSION_CODE 132117
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
